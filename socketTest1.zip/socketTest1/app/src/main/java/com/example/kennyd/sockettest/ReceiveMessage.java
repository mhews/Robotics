package com.example.kennyd.sockettest;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;

import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * Created by d31r498 on 4/5/2018.
 */

public class ReceiveMessage extends Thread {
    public Handler handler;
    String response = null;
    Activity act;
    TextView tex;

    TTS tts;
    ReceiveMessage(TTS t, Activity a){
        tts = t;
        //tex = (TextView) a.findViewById(R.id.retText);
        //tex.setText("YOOOOOOOOOOOOOO");
    }
    public void run() {

                try {
                    ServerSocket serverSocket = new ServerSocket(1223);
                    Log.v("LOG", "server");
                    Socket socket = null;
                    while(true){
                        String message = "";
                        try {
                            socket = serverSocket.accept();
                        }
                        catch(IOException e){
                            Log.v("FUUU","FUUUUUUUU");
                        }
                        ObjectInputStream os = new ObjectInputStream(socket.getInputStream());
                        try {
                            message = (String)os.readObject();
                        } catch (ClassNotFoundException e) {
                            e.printStackTrace();
                        }
                        ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
                        oos.writeObject("Hi Client" + message);
                        os.close();
                        oos.close();
                        socket.close();

                        Message sendMsg = tts.handler.obtainMessage();
                        Bundle b = new Bundle();
                        b.putString("TT", "BIG ROBOT");
                        sendMsg.setData(b);
                        tts.handler.sendMessage(sendMsg);

                } }catch (IOException e) {
                    e.printStackTrace();
                }

        }



}
