package com.example.kennyd.sockettest;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Message;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.support.v7.widget.Toolbar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Enumeration;

public class MainActivity extends AppCompatActivity {
    TextView returnText;
    private SpeechRecognizer mSpeechRecognizer;
    private Intent mSpeechRecognizerIntent;
    private boolean mIslistening;
    TTS tts;
    ReceiveMessage rm;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        tts = new TTS(this);
        returnText = (TextView) findViewById(R.id.retText);
        tts.start();
        rm = new ReceiveMessage(tts, this);
        rm.start();
        Message sendMsg = tts.handler.obtainMessage();
        //Message sendMsg = new Message();
        Bundle b = new Bundle();
        b.putString("TT", "WOW");
        sendMsg.setData(b);
        tts.handler.sendMessage(sendMsg);
        setContentView(R.layout.activity_main);
        String p = getIpAddress();
        final EditText editText = (EditText) findViewById(R.id.editText);
        Button button = (Button) findViewById(R.id.button);

        //returnText.setText(p);
        button.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){
                //new SendMessage().execute(editText.getText().toString());
                editText.getText();
            }
        });

        mSpeechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        mSpeechRecognizerIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        mSpeechRecognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        mSpeechRecognizerIntent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE,
                this.getPackageName());
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            this.requestPermissions(
                    new String[]{Manifest.permission.RECORD_AUDIO},
                    0);        }

        RecognitionListener listener = new RecognitionListener() {
            @Override
            public void onReadyForSpeech(Bundle params) {

            }

            @Override
            public void onBeginningOfSpeech() {

            }

            @Override
            public void onRmsChanged(float rmsdB) {

            }

            @Override
            public void onBufferReceived(byte[] buffer) {

            }

            @Override
            public void onEndOfSpeech() {
                Log.v("LOG", "HI");

            }

            @Override
            public void onError(int error) {
                mSpeechRecognizer.startListening(mSpeechRecognizerIntent);

            }

            @Override
            public void onResults(Bundle results) {
                ArrayList<String> result = results
                        .getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                //returnText.setText(result.get(0), TextView.BufferType.EDITABLE);
                Log.v("LOG", result.get(0));

//                mSpeechRecognizer.startListening(mSpeechRecognizerIntent);
//                new Thread(new Runnable() {
//                    public void run() {
//                        ArrayList<String> result = results
//                                .getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
//                        Log.v("LOG", result.get(0));
//                        mSpeechRecognizer.startListening(mSpeechRecognizerIntent);
//                    }
//                });
            }

            @Override
            public void onPartialResults(Bundle partialResults) {

            }

            @Override
            public void onEvent(int eventType, Bundle params) {

            }
        };

        mSpeechRecognizer.setRecognitionListener(listener);
        mSpeechRecognizer.startListening(mSpeechRecognizerIntent);


    }

//   class SendMessage extends AsyncTask<String, Void, String> {
//               private Exception exception;
//
//        @Override
//        protected String doInBackground(String... params) {
//            String response = null;
//            try {
//                try {
//                    ServerSocket serverSocket = new ServerSocket(8888);
//                    Socket socket = serverSocket.accept();
//                    serverSocket.serve_forever();
//                    BufferedReader outToServer = new BufferedReader(new InputStreamReader(socket.getInputStream()));
//                    int readed = outToServer.read();
//
//                    int lockSeconds = 10*1000;
//                    long lockThreadCheckpoint = System.currentTimeMillis();
//                    InputStream input = socket.getInputStream();
//                    int availableBytes = input.available();
//                    while(availableBytes <=0 && (System.currentTimeMillis() < lockThreadCheckpoint + lockSeconds)){
//                        try{Thread.sleep(10);}catch(InterruptedException ie){ie.printStackTrace();}
//                        availableBytes = input.available();
//                    }
//                    byte[] buffer = new byte[availableBytes];
//                    input.read(buffer, 0, availableBytes);
//                    response = new String(buffer);
//
//                    Message sendMsg = tts.handler.obtainMessage();
//                    Bundle b = new Bundle();
//                    b.putString("TT", response);
//                    sendMsg.setData(b);
//                    tts.handler.sendMessage(sendMsg);
//
//                    outToServer.close();
//                    //input.close();
//                    socket.close();
//
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//            } catch (Exception e) {
//                this.exception = e;
//                return null;
//            }
//            return response;
//        }
//       protected String doInBackground(String... params) {
//           String response = null;
//           try {
//               try {
//                   Socket socket = new Socket("192.168.42.80", 8888);
//                   PrintWriter outToServer = new PrintWriter(
//                           new OutputStreamWriter(
//                                   socket.getOutputStream()));
//                   outToServer.print(params[0]);
//                   outToServer.flush();
//
//                   InputStream input = socket.getInputStream();
//                   int lockSeconds = 10 * 1000;
//
//                   int availableBytes = input.available();
//
//                   byte[] buffer = new byte[availableBytes];
//                   input.read(buffer, 0, availableBytes);
//                   response = new String(buffer);
//                   outToServer.close();
//                   input.close();
//                   //socket.close();
//
//               } catch (IOException e) {
//                   e.printStackTrace();
//               }
//           } catch (Exception e) {
//               this.exception = e;
//               return null;
//           }
//           return response;
//       }

//       protected void onPostExecute(String response) {
//           returnText.setText(response);
//       }
//   }

    public static String getIpAddress() {
        String ipAddress = "Unable to Fetch IP..";
        try {
            Enumeration en;
            en = NetworkInterface.getNetworkInterfaces();
            while ( en.hasMoreElements()) {
                NetworkInterface intf = (NetworkInterface)en.nextElement();
                for (Enumeration enumIpAddr = intf.getInetAddresses(); enumIpAddr.hasMoreElements();) {
                    InetAddress inetAddress = (InetAddress)enumIpAddr.nextElement();
                    if (!inetAddress.isLoopbackAddress()&&inetAddress instanceof Inet4Address) {
                        ipAddress=inetAddress.getHostAddress().toString();
                        return ipAddress;
                    }
                }
            }
        } catch (SocketException ex) {
            ex.printStackTrace();
        }
        return ipAddress;
    }
}