package com.example.kennyd.sockettest;

import android.os.AsyncTask;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;

public class SendMessage  {
    //extends AsyncTask<String, Void, String>
//    private Exception exception;
//
//    @Override
//    protected String doInBackground(String... params) {
//        String response = null;
//        try {
//            try {
//                Socket socket = new Socket("192.168.1.119", 8888);
//                PrintWriter outToServer = new PrintWriter(
//                        new OutputStreamWriter(
//                                socket.getOutputStream()));
//                outToServer.print(params[0]);
//                outToServer.flush();
//
//                InputStream input = socket.getInputStream();
//                int lockSeconds = 10*1000;
//
//                int availableBytes = input.available();
//
//                byte[] buffer = new byte[availableBytes];
//                input.read(buffer, 0,availableBytes);
//                response = new String(buffer);
//                outToServer.close();
//                input.close();
//                socket.close();
//
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        } catch (Exception e) {
//            this.exception = e;
//            return null;
//        }
//        return response;
//    }
//
//    protected void onPostExecute(String response){
//        //returnText.setText(response);
//    }
}