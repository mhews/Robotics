package com.example.kennyd.robot;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.Enumeration;
import java.util.Locale;

public class Server {
    MainActivity a;
    ServerSocket s;
    String msg = "";
    String tts = "";
    TTS Tts;
    static final int sPORT = 8080;
    BufferedReader in;

    public Server(MainActivity activity) {
        this.a = activity;
        Thread socketServerThread = new Thread(new SocketServerThread());
        socketServerThread.start();
    }

    public int getPort() {
        return sPORT;
    }

    public void onDestroy() {
        if (s != null) {
            try {
                s.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }

    private class SocketServerThread extends Thread {


        @Override
        public void run() {
            try {
                s = new ServerSocket(sPORT);

                while (true) {
                    Socket socket = s.accept();
                    msg += " from "
                            + socket.getInetAddress() + ":"
                            + socket.getPort() + "\n";

                    a.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            a.msgText.setText(msg);
                        }
                    });

                    SocketServerListenerThread socketServerListenerThread =
                            new SocketServerListenerThread(socket);
                    socketServerListenerThread.run();

                    SocketServerReplyThread socketServerReplyThread =
                            new SocketServerReplyThread(socket);
                    socketServerReplyThread.run();

                }
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }

    private class SocketServerListenerThread extends Thread {

        private Socket listenThreadSocket;
        private BufferedReader input;

        SocketServerListenerThread(Socket socket) {
            listenThreadSocket = socket;
        }

        @Override
        public void run() {
            try {
                input = new BufferedReader(new InputStreamReader(listenThreadSocket.getInputStream()));
                msg += input.readLine() + "\n";
                tts = input.readLine();
                //input.close();

            } catch (IOException e) {
                e.printStackTrace();
                msg += "Listen " + e.toString() + "\n";
            }
            a.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    a.msgText.setText(msg);
                }
            });
            TTS ttsThread = new TTS(a);
            ttsThread.run();

            Message sendMsg = ttsThread.handler.obtainMessage();
            Bundle b = new Bundle();
            b.putString("TT", tts);
            sendMsg.setData(b);
            ttsThread.handler.sendMessage(sendMsg);
        }
    }

    private class SocketServerReplyThread extends Thread {

        private Socket hostThreadSocket;

        SocketServerReplyThread(Socket socket) {
            hostThreadSocket = socket;
        }

        @Override
        public void run() {
            OutputStream oStream;
            String msgReply = "Hello from Server";

            try {
                oStream = hostThreadSocket.getOutputStream();
                PrintStream pStream = new PrintStream(oStream);
                pStream.print(msgReply);
                pStream.close();

                msg += "replayed: " + msgReply + "\n";

                a.runOnUiThread(new Runnable() {

                    @Override
                    public void run() {
                        a.msgText.setText(msg);
                    }
                });

            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                msg += "Something wrong! " + e.toString() + "\n";
            }

            a.runOnUiThread(new Runnable() {

                @Override
                public void run() {
                    a.msgText.setText(msg);
                }
            });
        }

    }

    public static String getIpAddress() {
        String ip = "Unable to Fetch IP..";
        try {
            Enumeration en;
            en = NetworkInterface.getNetworkInterfaces();
            while (en.hasMoreElements()) {
                NetworkInterface intf = (NetworkInterface) en.nextElement();
                for (Enumeration enumIpAddr = intf.getInetAddresses(); enumIpAddr.hasMoreElements(); ) {
                    InetAddress inetAddress = (InetAddress) enumIpAddr.nextElement();
                    if (!inetAddress.isLoopbackAddress() && inetAddress instanceof Inet4Address) {
                        ip = inetAddress.getHostAddress().toString();
                        return ip;
                    }
                }
            }
        } catch (SocketException ex) {
            ex.printStackTrace();
        }
        return ip;
    }

    public static class TTS extends Thread implements TextToSpeech.OnInitListener{
        private String rtts;

//        TTS(String stts) {
//            rtts = stts;
//        }


        private TextToSpeech tts;
        private Context context;
        public Handler handler;
        private String last;

        TTS(Context con) {
            context = con;
            tts = new TextToSpeech(con,this);
            last = "";
        }

        public void onInit(int status) {
            if (status == TextToSpeech.SUCCESS) {
                int result = tts.setLanguage(Locale.US);
                tts.setPitch(0);
                tts.setSpeechRate(0);
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    Toast.makeText(context, "Language or Data not working", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(context, "Init failed", Toast.LENGTH_SHORT).show();
                }
            }
        }

        public void run() {
            Looper.prepare();

            handler = new Handler() {
                public void handleMessage(Message msg) {
                    String response = msg.getData().getString("TT");
                    Log.v("***SPEECH*** ", response);
                    speakOut(response);
                }
            };


            Looper.loop();
        }

        public void speakOut(String text) {
            if (last != text) {
                last = text;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
                } else {
                    tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
                }
                while (tts.isSpeaking()) {
                    try {
                        Thread.sleep(200);
                    } catch (Exception e) {
                    }
                }
            }
        }
    }
}