package com.example.kennyd.robot;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.Enumeration;
import java.util.Locale;

public class Server {
    MainActivity a;
    ServerSocket s;
    String msg = "";
    String tts = "";
    TTS ttsThread;
    public Socket socket;
    static final int sPORT = 8080;
    BufferedReader in;
    public SocketServerReplyThread stThread;

    public Server(MainActivity activity) {
        this.a = activity;
        Thread socketServerThread = new Thread(new SocketServerThread());
        socketServerThread.start();
    }

    public int getPort() {
        return sPORT;
    }

    public void onDestroy() {
        if (ttsThread != null){

        }
        if (s != null) {
            try {
                s.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }

    private class SocketServerThread extends Thread {


        @Override
        public void run() {
            ttsThread = new TTS(a);
            ttsThread.start();
            try {
                s = new ServerSocket(sPORT);

                while (true) {
                    socket = s.accept();
                    msg += " from "
                            + socket.getInetAddress() + ":"
                            + socket.getPort() + "\n";

                    a.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            a.msgText.setText(msg);
                        }
                    });

                    SocketServerListenerThread socketServerListenerThread =
                            new SocketServerListenerThread(socket);
                    socketServerListenerThread.start();

                    stThread =
                            new SocketServerReplyThread();
                    stThread.start();

                }
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }

    private class SocketServerListenerThread extends Thread {

        private Socket listenThreadSocket;
        private BufferedReader input;

        SocketServerListenerThread(Socket socket) {
            listenThreadSocket = socket;
        }

        @Override
        public void run() {
                try {
                    input = new BufferedReader(new InputStreamReader(listenThreadSocket.getInputStream()));
                    tts = input.readLine();
                    msg += tts + "\n";

                    //input.close();

                } catch (IOException e) {
                    //e.printStackTrace();
                    msg += "Listen " + e.toString() + "\n";
                }
                a.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        a.msgText.setText(msg);
                    }
                });

                try {
                    Message sendMsg = ttsThread.handler.obtainMessage();
                    Bundle b = new Bundle();
                    b.putString("TT", tts);
                    sendMsg.setData(b);
                    ttsThread.handler.sendMessage(sendMsg);
                } catch (NullPointerException e) {
                    Log.v("LOG", ":(");
                }

        }
    }

    public class SocketServerReplyThread extends Thread{
        public Handler handler;
        private Socket hostThreadSocket;

        SocketServerReplyThread() {
            hostThreadSocket = socket;
        }

        @Override
        public void run() {
            OutputStream oStream;
            String msgReply = "Hello from Server";

            Looper.prepare();
            hostThreadSocket = socket;

            handler = new Handler() {
                public void handleMessage(Message msg) {
                    String response = msg.getData().getString("SS");
                    //Log.v("***SPEECH*** ", response);
                    //speakOut(response);
                    String[] parts = response.split(" ");
                    for(int i = 0;i<parts.length;i++){
                        if(parts[i].equals("start")||parts[i].equals("hello")||parts[i].equals("bye")||parts[i].equals("weather")||parts[i].equals("name")||parts[i].equals("cats")){
                            try{
                                OutputStream oStream;
                                oStream = hostThreadSocket.getOutputStream();
                                PrintStream pStream = new PrintStream(oStream);
                                pStream.print(parts[i]);

                            }catch(IOException e){
                                e.printStackTrace();
                            }
                        }
                    }
                }
            };


            Looper.loop();
//            try {
//                oStream = hostThreadSocket.getOutputStream();
//                PrintStream pStream = new PrintStream(oStream);
//                pStream.print(msgReply);
//                //pStream.close();
//
//                msg += "replayed: " + msgReply + "\n";
//
//                a.runOnUiThread(new Runnable() {
//
//                    @Override
//                    public void run() {
//                        a.msgText.setText(msg);
//                    }
//                });
//
//            } catch (IOException e) {
//                // TODO Auto-generated catch block
//                e.printStackTrace();
//                msg += "Something wrong! " + e.toString() + "\n";
//            }
//
//            a.runOnUiThread(new Runnable() {
//
//                @Override
//                public void run() {
//                    a.msgText.setText(msg);
//                }
//            });
        }

    }

    public static String getIpAddress() {
        String ip = "Unable to Fetch IP..";
        try {
            Enumeration en;
            en = NetworkInterface.getNetworkInterfaces();
            while (en.hasMoreElements()) {
                NetworkInterface intf = (NetworkInterface) en.nextElement();
                for (Enumeration enumIpAddr = intf.getInetAddresses(); enumIpAddr.hasMoreElements(); ) {
                    InetAddress inetAddress = (InetAddress) enumIpAddr.nextElement();
                    if (!inetAddress.isLoopbackAddress() && inetAddress instanceof Inet4Address) {
                        ip = inetAddress.getHostAddress().toString();
                        return ip;
                    }
                }
            }
        } catch (SocketException ex) {
            ex.printStackTrace();
        }
        return ip;
    }

    public static class TTS extends Thread implements TextToSpeech.OnInitListener{
        private String rtts;

//        TTS(String stts) {
//            rtts = stts;
//        }


        private TextToSpeech tts;
        private Context context;
        public Handler handler;
        private String last;

        TTS(Context con) {
            context = con;
            Log.v("LLLLLLOOOOOOGGGGGG", "yoooo");
            tts = new TextToSpeech(con,this);
            last = "";
        }

        public void onInit(int status) {
            if (status == TextToSpeech.SUCCESS) {
                int result = tts.setLanguage(Locale.US);
                tts.setPitch(0);
                tts.setSpeechRate(0);
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    Toast.makeText(context, "Language or Data not working", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(context, "Init failed", Toast.LENGTH_SHORT).show();
                }
            }
        }

        public void run() {
            Looper.prepare();

            handler = new Handler() {
                public void handleMessage(Message msg) {
                    String response = msg.getData().getString("TT");
                    //Log.v("***SPEECH*** ", response);
                    speakOut(response);
                }
            };


            Looper.loop();
        }

        public void speakOut(String text) {
            if (last != text) {
                last = text;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
                } else {
                    tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
                }
                while (tts.isSpeaking()) {
                    try {
                        Thread.sleep(200);
                    } catch (Exception e) {
                    }
                }
            }
        }
    }
}