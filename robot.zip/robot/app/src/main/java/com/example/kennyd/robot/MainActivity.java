package com.example.kennyd.robot;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.app.Activity;
import android.os.Message;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends Activity {
    private SpeechRecognizer mSpeechRecognizer;
    private Intent mSpeechRecognizerIntent;
    Server server;
    Server.SocketServerReplyThread sThread;
    TextView ipText, msgText;
//    Server.TTS tts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        ipText = (TextView) findViewById(R.id.ipText);
        msgText = (TextView) findViewById(R.id.msgText);
        server = new Server(this);
        ipText.setText(server.getIpAddress() + ":" + server.getPort());
//        tts = new Server.TTS(this);
//        tts.start();
        mSpeechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        mSpeechRecognizerIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        mSpeechRecognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        mSpeechRecognizerIntent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE,
                this.getPackageName());
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            this.requestPermissions(
                    new String[]{Manifest.permission.RECORD_AUDIO},
                    0);        }

        RecognitionListener listener = new RecognitionListener() {
            @Override
            public void onReadyForSpeech(Bundle params) {

//                try {
//
//                    sThread = server.stThread;
//                    sThread.start();
//                }
//                catch(Exception e){
//                    Log.v("LOG", e.toString());
//                }
            }

            @Override
            public void onBeginningOfSpeech() {

            }

            @Override
            public void onRmsChanged(float rmsdB) {

            }

            @Override
            public void onBufferReceived(byte[] buffer) {

            }

            @Override
            public void onEndOfSpeech() {
                mSpeechRecognizer.startListening(mSpeechRecognizerIntent);

            }

            @Override
            public void onError(int error) {
                if ((error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) || (error == SpeechRecognizer.ERROR_NO_MATCH)){
                    Log.v("LOG", "PLES");
                    mSpeechRecognizer.stopListening();
                    mSpeechRecognizer.startListening(mSpeechRecognizerIntent);

                }

            }

            @Override
            public void onResults(Bundle results) {
                ArrayList<String> result = results
                        .getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                Log.v("LOG", result.get(0));
                try {
                    Message sendMsg = server.stThread.handler.obtainMessage();
                    Bundle b = new Bundle();
                    b.putString("SS", result.get(0));
                    sendMsg.setData(b);
                    server.stThread.handler.sendMessage(sendMsg);
                }
                catch(NullPointerException e){
                    Log.v("LOG", e.toString());
                }
                mSpeechRecognizer.startListening(mSpeechRecognizerIntent);
//                new Thread(new Runnable() {
//                    public void run() {
//                        ArrayList<String> result = results
//                                .getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
//                        Log.v("LOG", result.get(0));
//                        mSpeechRecognizer.startListening(mSpeechRecognizerIntent);
//                    }
//                });
            }

            @Override
            public void onPartialResults(Bundle partialResults) {

            }

            @Override
            public void onEvent(int eventType, Bundle params) {

            }
        };

        mSpeechRecognizer.setRecognitionListener(listener);
        mSpeechRecognizer.startListening(mSpeechRecognizerIntent);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        server.onDestroy();
    }
}