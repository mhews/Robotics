package com.example.kennyd.robot;

import android.os.Bundle;
import android.app.Activity;
import android.widget.TextView;

public class MainActivity extends Activity {

    Server server;
    TextView ipText, msgText;
//    Server.TTS tts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ipText = (TextView) findViewById(R.id.ipText);
        msgText = (TextView) findViewById(R.id.msgText);
        server = new Server(this);
        ipText.setText(server.getIpAddress() + ":" + server.getPort());
//        tts = new Server.TTS(this);
//        tts.start();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        server.onDestroy();
    }
}